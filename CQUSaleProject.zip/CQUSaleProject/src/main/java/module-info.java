module com.mycompany.cqusaleproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.cqusaleproject to javafx.fxml;
    exports com.mycompany.cqusaleproject;
}
